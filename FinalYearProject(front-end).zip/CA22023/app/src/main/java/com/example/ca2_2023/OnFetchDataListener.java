package com.example.ca2_2023;

import java.util.List;

import models.NewsHeadlines;

public interface OnFetchDataListener <NewsApiResponse>{
    void onFetchData(List<NewsHeadlines> list, String message);
    void onError(String message);
}
