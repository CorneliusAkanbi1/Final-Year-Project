package com.example.ca2_2023;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

public class Metrics extends AppCompatActivity {

    // Constant to identify the request for external storage permission
    private static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_metrics);

        // Check if the permission is not granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            // Request the permission
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);
        } else {
            // Permission is already granted, proceed to run the Python script
            new RunPythonScriptTask().execute();
        }
    }

    // Handle the result of the permission request
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE) {
            // Check if the permission was granted
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted, proceed to run the Python script
                new RunPythonScriptTask().execute();
            } else {
                // Permission denied, handle accordingly (e.g., show a message)
                // You may choose to inform the user about the necessity of the permission for the app to function properly
            }
        }
    }

    private class RunPythonScriptTask extends AsyncTask<Void, Void, String> {

        @Override
        protected String doInBackground(Void... voids) {
            try {
                String oneDrivePath = "/mnt/sdcard/OneDrive - Technological University Dublin";
                String finalYearProjectPath = oneDrivePath + "/FinalYearProject";
                String motionDetectionPath = finalYearProjectPath + "/MotionDetection";
                String pythonScriptPath = motionDetectionPath + "/SquatDepthTest.py";

                // Provide the full path to the Python executable
                String pythonExecutable = "/data/data/com.termux/files/usr/bin/python"; // Update with the actual path

                // Check if the Python executable exists
                File pythonFile = new File(pythonExecutable);
                if (!pythonFile.exists()) {
                    return "Error: Python executable not found.";
                }

                // Build the command
                ProcessBuilder processBuilder = new ProcessBuilder(pythonExecutable, pythonScriptPath);

                // Set the working directory
                processBuilder.directory(new File(motionDetectionPath));

                // Redirect error stream to output stream
                processBuilder.redirectErrorStream(true);

                // Start the process
                Process process = processBuilder.start();

                // Read the output of the Python script
                BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
                StringBuilder output = new StringBuilder();
                String line;
                while ((line = reader.readLine()) != null) {
                    output.append(line).append("\n");
                }

                // Optionally, log or display the output
                System.out.println("Python script output:\n" + output.toString());

                // Wait for the Python script to finish
                int exitCode = process.waitFor();
                System.out.println("Python script exited with code: " + exitCode);

                return output.toString();

            } catch (IOException | InterruptedException e) {
                e.printStackTrace();
                return "Error: " + e.getMessage();
            }
        }

        @Override
        protected void onPostExecute(String result) {
        }
    }
}
